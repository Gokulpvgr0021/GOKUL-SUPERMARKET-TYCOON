# PVGR TYCOON – Android APK project

The game is in `www/index.html`. The supplied TYCOON artwork is configured as the Android launcher icon, browser favicon, and installable web-app icon. The project uses Capacitor 6 and Three.js. The Three.js runtime is copied into `www/lib/` during `npm install`, so the packaged game can run offline.

## Build an APK automatically (no Android Studio needed on your computer)

This project includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.

1. Sign in to GitHub and create a new empty repository.
2. Extract this ZIP on a computer, then upload the CONTENTS of the `pvgr-mobile` folder to the repository root. Make sure `.github/workflows/android-apk.yml` is included. Do not upload only the ZIP file if you want the included workflow to run automatically.
3. Open the repository's **Actions** tab.
4. Select **Build PVGR TYCOON APK** and press **Run workflow** (or push to `main`/`master`).
5. When the workflow finishes successfully, open that workflow run and download the **PVGR-TYCOON-debug-APK** artifact.
6. Extract the downloaded artifact ZIP on your Android phone and install `app-debug.apk`. If Android asks, allow installation from that source.

The workflow installs dependencies, creates the native Android project, and compiles the debug APK using GitHub's Android build environment. A debug APK is suitable for direct testing/installation; a Play Store release requires a separately signed release build.

## Build locally (optional)

Requirements: Node.js 18+, JDK 17, Android SDK. Then run:

```bash
npm install
npm run android:setup
npm run android:debug
```

APK output: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Project details

- App ID: `com.pvgr.tycoon`
- App name: `PVGR TYCOON`
- Game source: `www/index.html`
- Saves: device `localStorage`; use Settings > Copy/Load save code for manual backup.
- Graphics settings and 30/60 FPS options are available in-game.

This project archive does not contain a prebuilt APK. The APK is produced by the Android build workflow after it runs successfully.
