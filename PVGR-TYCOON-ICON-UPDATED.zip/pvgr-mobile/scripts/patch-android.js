// Run after "npx cap add android": allow rotation, force GPU acceleration, install branded launcher icons.
const fs=require('fs'),path=require('path');
const manifest='android/app/src/main/AndroidManifest.xml';
if(!fs.existsSync(manifest)){console.error('Android project not found. Run "npx cap add android" first.');process.exit(1)}
let x=fs.readFileSync(manifest,'utf8');
if(!x.includes('android:screenOrientation=')) x=x.replace('<activity','<activity android:screenOrientation="fullUser"');
if(!x.includes('android:hardwareAccelerated=')) x=x.replace('<activity','<activity android:hardwareAccelerated="true"');
fs.writeFileSync(manifest,x);
const src=path.join(__dirname,'..','resources','android');
const dst='android/app/src/main/res';
if(!fs.existsSync(src)){console.error('Branded Android icon resources are missing:',src);process.exit(1)}
fs.cpSync(src,dst,{recursive:true});
console.log('Patched Android manifest and installed TYCOON launcher icons.');
