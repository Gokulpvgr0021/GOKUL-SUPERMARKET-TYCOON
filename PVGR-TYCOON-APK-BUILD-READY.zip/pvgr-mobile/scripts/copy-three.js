const fs=require('fs'),path=require('path');
const src=path.join(__dirname,'..','node_modules','three','build','three.min.js');
const dst=path.join(__dirname,'..','www','lib','three.min.js');
if(!fs.existsSync(src)){console.error('three.min.js not found. Run "npm install" first.');process.exit(1)}
fs.mkdirSync(path.dirname(dst),{recursive:true});fs.copyFileSync(src,dst);
console.log('Copied three.js r128 ->',dst);
