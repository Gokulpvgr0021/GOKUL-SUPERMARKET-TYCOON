// Run after "npx cap add android": allow rotation, force GPU acceleration.
const fs=require('fs'),p='android/app/src/main/AndroidManifest.xml';
if(!fs.existsSync(p)){console.error('Android project not found. Run "npx cap add android" first.');process.exit(1)}
let x=fs.readFileSync(p,'utf8');
const add=a=>{if(!x.includes(a.split('=')[0]+'='))x=x.replace('<activity',`<activity ${a}`)};
add('android:screenOrientation="fullUser"');add('android:hardwareAccelerated="true"');
fs.writeFileSync(p,x);console.log('Patched',p);
