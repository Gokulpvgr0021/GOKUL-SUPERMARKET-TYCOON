extends Node3D

const FLOOR_SIZE := Vector2(18.0, 22.0)
var cash := 120
var level := 1
var customers_served := 0
var elapsed := 0.0
var player: Node3D
var customers: Array[Node3D] = []
var cash_label: Label
var level_label: Label
var task_label: Label
var message_label: Label
var move_dir := Vector2.ZERO
var dragging := false
var last_touch := Vector2.ZERO

func _ready() -> void:
    _build_world()
    _build_player()
    _build_customers()
    _build_ui()
    _update_ui()

func _process(delta: float) -> void:
    elapsed += delta
    if elapsed >= 5.0:
        elapsed = 0.0
        cash += 8 + level * 2
        customers_served += 1
        _update_ui()
    if player and move_dir.length() > 0.05:
        var v := Vector3(move_dir.x, 0, move_dir.y).normalized()
        player.position += v * 4.0 * delta
        player.position.x = clampf(player.position.x, -7.8, 7.8)
        player.position.z = clampf(player.position.z, -9.0, 9.0)
        player.rotation.y = atan2(v.x, v.z)
    for i in customers.size():
        var c := customers[i]
        var t := Time.get_ticks_msec() / 1000.0 + float(i) * 1.7
        c.position.x = sin(t * 0.45 + i) * (3.0 + float(i % 3))
        c.position.z = cos(t * 0.35 + i * 0.8) * (4.0 + float(i % 2))
        c.rotation.y = t * 0.3

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            dragging = true
            last_touch = event.position
        else:
            dragging = false
            move_dir = Vector2.ZERO
    elif event is InputEventScreenDrag and dragging:
        var d: Vector2 = event.position - last_touch
        move_dir = Vector2(clampf(d.x / 90.0, -1, 1), clampf(d.y / 90.0, -1, 1))
    elif event is InputEventKey and event.pressed:
        if event.keycode == KEY_LEFT: move_dir = Vector2.LEFT
        elif event.keycode == KEY_RIGHT: move_dir = Vector2.RIGHT
        elif event.keycode == KEY_UP: move_dir = Vector2.UP
        elif event.keycode == KEY_DOWN: move_dir = Vector2.DOWN

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color("#d9e8f2")
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color.WHITE
    e.ambient_light_energy = 0.8
    env.environment = e
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -30, 0)
    sun.light_energy = 1.25
    add_child(sun)

    _box("Floor", Vector3(0, -0.25, 0), Vector3(18, 0.5, 22), Color("#f4d9a6"))
    _box("BackWall", Vector3(0, 2.4, -11), Vector3(18, 5, 0.45), Color("#e94e36"))
    _box("LeftWall", Vector3(-9, 2.4, 0), Vector3(0.45, 5, 22), Color("#e94e36"))
    _box("RightLowWall", Vector3(9, 1.2, 1), Vector3(0.45, 2.4, 20), Color("#e94e36"))
    _box("FrontGlass", Vector3(0, 1.1, 10.8), Vector3(18, 2.2, 0.18), Color("#8dd8ee"))
    _add_shelf(Vector3(-5.7, 0.7, -7.2))
    _add_shelf(Vector3(-1.8, 0.7, -7.2))
    _add_shelf(Vector3(2.2, 0.7, -7.2))
    _add_shelf(Vector3(6.0, 0.7, -7.2))
    _add_shelf(Vector3(6.3, 0.7, -2.0))
    _add_shelf(Vector3(6.3, 0.7, 3.0))
    _add_checkout(Vector3(-5.8, 0, 4.8))
    _add_escalator(Vector3(-5.8, 0, 8.1))
    _add_tree(Vector3(-10.3, 0, -8.5))
    _add_tree(Vector3(10.2, 0, -8.8))

    var title := Label3D.new()
    title.text = "GOKUL MARKET"
    title.font_size = 64
    title.position = Vector3(0, 4.2, -10.55)
    title.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    title.modulate = Color("#fff3d5")
    add_child(title)

    var cam := Camera3D.new()
    cam.position = Vector3(16, 21, 24)
    cam.look_at(Vector3(0, 0, 0), Vector3.UP)
    cam.projection = Camera3D.PROJECTION_ORTHOGONAL
    cam.size = 31
    add_child(cam)
    cam.current = true

func _build_player() -> void:
    player = _person(Color("#2468d8"), Color("#f1bd91"), Vector3(0, 0, 5.8))
    player.name = "Player"
    add_child(player)

func _build_customers() -> void:
    var colors := [Color("#ef5350"), Color("#ffca28"), Color("#ab47bc"), Color("#26a69a"), Color("#ec407a"), Color("#5c6bc0")]
    for i in 6:
        var c := _person(colors[i], Color("#d99b70"), Vector3.ZERO)
        c.name = "Customer_%d" % i
        customers.append(c)
        add_child(c)

func _person(shirt: Color, skin: Color, at: Vector3) -> Node3D:
    var root := Node3D.new()
    root.position = at
    var body := _mesh_box(Vector3(0, 0.85, 0), Vector3(0.62, 0.9, 0.38), shirt)
    root.add_child(body)
    var head := _mesh_sphere(Vector3(0, 1.55, 0), 0.28, skin)
    root.add_child(head)
    var legs := _mesh_box(Vector3(0, 0.25, 0), Vector3(0.48, 0.5, 0.34), Color("#30384b"))
    root.add_child(legs)
    return root

func _add_shelf(at: Vector3) -> void:
    var s := Node3D.new()
    s.position = at
    add_child(s)
    s.add_child(_mesh_box(Vector3(0, 0.1, 0), Vector3(2.3, 0.2, 0.85), Color("#5c4235")))
    for y in [0.75, 1.45, 2.15]:
        s.add_child(_mesh_box(Vector3(0, y, 0), Vector3(2.25, 0.12, 0.82), Color("#f4f4f4")))
        for x in [-0.75, 0.0, 0.75]:
            var colors := [Color("#f2c230"), Color("#e85d45"), Color("#52ae70"), Color("#478bd1")]
            s.add_child(_mesh_box(Vector3(x, y + 0.28, 0), Vector3(0.38, 0.42, 0.45), colors[randi() % colors.size()]))

func _add_checkout(at: Vector3) -> void:
    _box("CheckoutDesk", at + Vector3(0, 0.55, 0), Vector3(2.8, 1.1, 1.1), Color("#8a5134"))
    _box("CheckoutTop", at + Vector3(0, 1.15, 0), Vector3(2.9, 0.15, 1.15), Color("#f6e8d0"))
    _box("Register", at + Vector3(0.7, 1.55, -0.1), Vector3(0.65, 0.55, 0.5), Color("#34495e"))

func _add_escalator(at: Vector3) -> void:
    _box("EscalatorBase", at, Vector3(3.0, 0.25, 4.8), Color("#39434d"))
    for i in 8:
        _box("Step_%d" % i, at + Vector3(0, 0.2 + i * 0.13, -1.8 + i * 0.48), Vector3(2.6, 0.12, 0.42), Color("#737f89"))
    _box("RailLeft", at + Vector3(-1.55, 0.9, 0), Vector3(0.14, 1.5, 4.8), Color("#e9a83b"))
    _box("RailRight", at + Vector3(1.55, 0.9, 0), Vector3(0.14, 1.5, 4.8), Color("#e9a83b"))

func _add_tree(at: Vector3) -> void:
    _box("TreeTrunk", at + Vector3(0, 1, 0), Vector3(0.45, 2, 0.45), Color("#765039"))
    var crown := _mesh_sphere(at + Vector3(0, 2.6, 0), 1.1, Color("#55a84f"))
    add_child(crown)

func _mesh_box(pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    var m := BoxMesh.new()
    m.size = size
    n.mesh = m
    n.position = pos
    n.material_override = _mat(color)
    return n

func _mesh_sphere(pos: Vector3, radius: float, color: Color) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    var m := SphereMesh.new()
    m.radius = radius
    m.height = radius * 2
    n.mesh = m
    n.position = pos
    n.material_override = _mat(color)
    return n

func _mat(color: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.85
    return m

func _box(n: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var b := _mesh_box(pos, size, color)
    b.name = n
    add_child(b)

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(18, 18)
    panel.size = Vector2(684, 150)
    layer.add_child(panel)
    var v := VBoxContainer.new()
    panel.add_child(v)
    cash_label = Label.new()
    cash_label.add_theme_font_size_override("font_size", 30)
    v.add_child(cash_label)
    level_label = Label.new()
    level_label.add_theme_font_size_override("font_size", 22)
    v.add_child(level_label)
    task_label = Label.new()
    task_label.text = "DRAG TO MOVE  •  SERVE CUSTOMERS  •  GROW YOUR STORE"
    task_label.add_theme_font_size_override("font_size", 16)
    v.add_child(task_label)

    var row := HBoxContainer.new()
    row.position = Vector2(18, 1080)
    row.size = Vector2(684, 150)
    layer.add_child(row)
    var restock := Button.new()
    restock.text = "RESTOCK\n₹40"
    restock.custom_minimum_size = Vector2(210, 100)
    restock.pressed.connect(_restock)
    row.add_child(restock)
    var upgrade := Button.new()
    upgrade.text = "UPGRADE\n₹100"
    upgrade.custom_minimum_size = Vector2(210, 100)
    upgrade.pressed.connect(_upgrade)
    row.add_child(upgrade)
    var collect := Button.new()
    collect.text = "COLLECT\n₹25"
    collect.custom_minimum_size = Vector2(210, 100)
    collect.pressed.connect(_collect)
    row.add_child(collect)

    message_label = Label.new()
    message_label.position = Vector2(18, 180)
    message_label.add_theme_font_size_override("font_size", 24)
    layer.add_child(message_label)

func _restock() -> void:
    if cash >= 40:
        cash -= 40
        message_label.text = "Shelves restocked!"
    else:
        message_label.text = "Need more cash to restock!"
    _update_ui()

func _upgrade() -> void:
    if cash >= 100:
        cash -= 100
        level += 1
        message_label.text = "Supermarket upgraded! Level %d" % level
    else:
        message_label.text = "Need ₹100 to upgrade!"
    _update_ui()

func _collect() -> void:
    cash += 25
    message_label.text = "₹25 collected!"
    _update_ui()

func _update_ui() -> void:
    if cash_label:
        cash_label.text = "💰 CASH: ₹%d" % cash
        level_label.text = "SUPERMARKET LEVEL: %d   |   CUSTOMERS SERVED: %d" % [level, customers_served]
