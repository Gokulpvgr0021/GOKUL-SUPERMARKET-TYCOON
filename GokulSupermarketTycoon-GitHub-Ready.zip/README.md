# GOKUL SUPERMARKET TYCOON

A portrait-mode 3D supermarket tycoon starter project made with Godot 4.4.

## Current prototype systems
- Isometric 3D supermarket layout, shelves, products, checkout and escalator
- Player character with drag-to-move touch controls
- Moving customer characters
- Cash income loop and customer counter
- Restock, collect and upgrade buttons
- Android portrait project configuration

## Build
Open this folder in Godot 4.4.1, install the matching Android export templates, configure Android SDK/JDK in Editor Settings, then export using the `Android` preset.

This is an early playable prototype, not a finished commercial game. It still needs visual polish, gameplay balancing, proper character animations, sound, save/load, additional floors and device testing before final release.
